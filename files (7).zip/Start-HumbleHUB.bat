@echo off
title HumbleHUB
color 0A

REM Get the folder where THIS bat file lives
SET BAT_DIR=%~dp0
cd /d "%BAT_DIR%"

echo.
echo  HumbleHUB - Starting...
echo  Bat location: %BAT_DIR%
echo.

REM Search for node.exe in subfolders of where the bat file is
SET NODE_EXE=
FOR /F "delims=" %%F IN ('dir /s /b "%BAT_DIR%node.exe" 2^>nul') DO (
  IF NOT DEFINED NODE_EXE SET NODE_EXE=%%F
)

IF DEFINED NODE_EXE (
  echo  Found: %NODE_EXE%
  GOTO :run
)

REM Try system node
where node >nul 2>&1
IF %ERRORLEVEL% EQU 0 (
  SET NODE_EXE=node
  GOTO :run
)

echo  [ERROR] Cannot find node.exe
echo.
echo  Make sure the node-v20.11.0-win-x64 folder is in the SAME
echo  folder as this bat file, not inside another folder.
echo.
pause
exit /b 1

:run
REM Verify server.js is next to this bat file
IF NOT EXIST "%BAT_DIR%server.js" (
  echo  [ERROR] server.js not found in %BAT_DIR%
  echo.
  echo  Make sure server.js is in the SAME folder as this bat file.
  echo  Current folder contents:
  dir "%BAT_DIR%" /b
  echo.
  pause
  exit /b 1
)

echo  Starting HumbleHUB...
echo  Open http://localhost:3000 in your browser
echo  Close this window to stop.
echo.
timeout /t 1 /nobreak >nul
start "" "http://localhost:3000"
"%NODE_EXE%" "%BAT_DIR%server.js"
pause
