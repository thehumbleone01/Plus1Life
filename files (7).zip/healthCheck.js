const https = require('https');
const http = require('http');

const cache = new Map();

function ping(url, timeoutMs = 8000) {
  return new Promise((resolve) => {
    const start = Date.now();
    const lib = url.startsWith('https') ? https : http;

    const req = lib.get(url, { timeout: timeoutMs }, (res) => {
      const ms = Date.now() - start;
      res.resume();
      resolve({ ok: res.statusCode < 400, status: res.statusCode, ms });
    });

    req.on('timeout', () => {
      req.destroy();
      resolve({ ok: false, status: 'timeout', ms: timeoutMs });
    });

    req.on('error', (err) => {
      resolve({ ok: false, status: err.code || 'error', ms: Date.now() - start });
    });
  });
}

async function checkAll(sites) {
  const results = await Promise.allSettled(
    sites.map(async (site) => {
      const result = await ping(site.url);
      const entry = {
        id: site.id,
        ok: result.ok,
        status: result.status,
        ms: result.ms,
        checkedAt: new Date().toISOString(),
        lastSeen: result.ok ? new Date().toISOString() : (cache.get(site.id)?.lastSeen || null)
      };
      cache.set(site.id, entry);
      return entry;
    })
  );

  return results.map((r, i) =>
    r.status === 'fulfilled' ? r.value : {
      id: sites[i].id,
      ok: false,
      status: 'error',
      ms: null,
      checkedAt: new Date().toISOString(),
      lastSeen: cache.get(sites[i].id)?.lastSeen || null
    }
  );
}

function getCache() {
  return Object.fromEntries(cache);
}

module.exports = { checkAll, getCache, ping };
