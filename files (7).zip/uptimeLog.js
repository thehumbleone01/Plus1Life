const fs = require('fs');
const path = require('path');
const LOG_FILE = path.join(__dirname, 'config', 'uptime-log.json');
const MAX_ENTRIES = 288; // 24h at 5min intervals

function load() {
  try { return JSON.parse(fs.readFileSync(LOG_FILE, 'utf8')); }
  catch { return {}; }
}

function save(data) {
  try { fs.writeFileSync(LOG_FILE, JSON.stringify(data)); } catch {}
}

function record(healthData) {
  const log = load();
  const ts = Date.now();
  Object.values(healthData).forEach(h => {
    if (!log[h.id]) log[h.id] = [];
    log[h.id].push({ ts, ok: h.ok });
    if (log[h.id].length > MAX_ENTRIES) log[h.id] = log[h.id].slice(-MAX_ENTRIES);
  });
  save(log);
}

function getUptime(siteId) {
  const log = load();
  const entries = log[siteId];
  if (!entries || entries.length === 0) return null;
  const cutoff = Date.now() - 24 * 60 * 60 * 1000;
  const recent = entries.filter(e => e.ts > cutoff);
  if (recent.length === 0) return null;
  const up = recent.filter(e => e.ok === true).length;
  return Math.round((up / recent.length) * 1000) / 10;
}

function getAllUptime() {
  const log = load();
  const result = {};
  Object.keys(log).forEach(id => { result[id] = getUptime(id); });
  return result;
}

module.exports = { record, getUptime, getAllUptime };
