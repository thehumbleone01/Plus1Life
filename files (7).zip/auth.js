const crypto = require('crypto');
const sessions = new Map();

function createSession() {
  const token = crypto.randomBytes(32).toString('hex');
  sessions.set(token, Date.now() + 24 * 60 * 60 * 1000);
  return token;
}

function validSession(token) {
  if (!token || !sessions.has(token)) return false;
  if (Date.now() > sessions.get(token)) { sessions.delete(token); return false; }
  return true;
}

function getCookie(req) {
  const m = (req.headers.cookie || '').match(/hub_session=([a-f0-9]{64})/);
  return m ? m[1] : null;
}

function requireAuth(req, res, authConfig, next) {
  if (!authConfig || !authConfig.enabled) return next();
  const url = req.url.split('?')[0];
  if (url === '/login' || url === '/api/login') return next();
  if (validSession(getCookie(req))) return next();
  if (req.url.startsWith('/api/')) {
    res.writeHead(401, {'Content-Type':'application/json'});
    return res.end(JSON.stringify({error:'Unauthorized'}));
  }
  res.writeHead(302, {Location:'/login'});
  res.end();
}

function handleLogin(req, res, authConfig) {
  let body = '';
  req.on('data', d => body += d);
  req.on('end', () => {
    let pw = '';
    try { pw = JSON.parse(body).password || ''; } catch(e) {}
    
    console.log('[login] attempt, stored:', JSON.stringify(authConfig.password), 'received:', JSON.stringify(pw));
    
    if (pw === authConfig.password) {
      const token = createSession();
      res.writeHead(200, {
        'Content-Type': 'application/json',
        'Set-Cookie': `hub_session=${token}; Path=/; HttpOnly; SameSite=Strict`
      });
      res.end(JSON.stringify({ok: true}));
    } else {
      res.writeHead(401, {'Content-Type':'application/json'});
      res.end(JSON.stringify({error:'Wrong password'}));
    }
  });
}

function handleLogout(req, res) {
  sessions.delete(getCookie(req));
  res.writeHead(302, {'Set-Cookie':'hub_session=; Path=/; Max-Age=0', Location:'/login'});
  res.end();
}

module.exports = { requireAuth, handleLogin, handleLogout };
