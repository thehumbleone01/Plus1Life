const http = require('http');
const fs = require('fs');
const path = require('path');
const { checkAll, getCache } = require('./healthCheck');
const uptimeLog = require('./uptimeLog');
const { requireAuth, handleLogin, handleLogout } = require('./auth');

const fs_check = require('fs');
// Support both development and Electron packaged mode
function resolveDir(name) {
  const candidates = [
    path.join(__dirname, name),
    path.join(process.resourcesPath || '', 'app.asar.unpacked', name),
    path.join(process.resourcesPath || '', name),
  ];
  return candidates.find(p => fs_check.existsSync(p)) || path.join(__dirname, name);
}
const CONFIG_DIR = resolveDir('config');
const PUBLIC_DIR = resolveDir('public');

function loadConfig() {
  const sites = JSON.parse(fs.readFileSync(path.join(CONFIG_DIR, 'sites.json'), 'utf8'));
  const apps = JSON.parse(fs.readFileSync(path.join(CONFIG_DIR, 'apps.json'), 'utf8'));
  const settings = JSON.parse(fs.readFileSync(path.join(CONFIG_DIR, 'settings.json'), 'utf8'));
  return { sites, apps, settings };
}

function flatSites(sitesConfig) {
  return sitesConfig.platforms.flatMap(p =>
    p.sites.map(s => ({ ...s, platformId: p.id, platformLabel: p.label }))
  );
}

function send(res, status, body, type = 'application/json') {
  res.writeHead(status, { 'Content-Type': type, 'Cache-Control': 'no-cache' });
  res.end(typeof body === 'string' ? body : JSON.stringify(body));
}

function serveFile(res, filePath) {
  fs.readFile(filePath, (err, data) => {
    if (err) return send(res, 404, '{"error":"Not found"}');
    const ext = path.extname(filePath);
    const types = { '.html': 'text/html', '.js': 'application/javascript', '.css': 'text/css', '.json': 'application/json', '.ico': 'image/x-icon' };
    send(res, 200, data, types[ext] || 'application/octet-stream');
  });
}

const { sites: sitesConfig, apps: appsConfig, settings } = loadConfig();
const { hub, auth: authConfig = { enabled: false } } = settings;

let healthData = {};

async function runChecks() {
  const allSites = flatSites(sitesConfig);
  const allApps = appsConfig.apps.filter(a => a.monitorUrl);
  const appSites = allApps.map(a => ({ id: a.id, url: a.monitorUrl }));
  const results = await checkAll([...allSites, ...appSites]);
  results.forEach(r => { healthData[r.id] = r; });
  uptimeLog.record(healthData);
  console.log(`[${new Date().toLocaleTimeString()}] Checked ${results.length} endpoints`);
}

runChecks();
setInterval(runChecks, hub.checkIntervalSeconds * 1000);

const server = http.createServer((req, res) => {
  const url = req.url.split('?')[0];

  if (url === '/login') return serveFile(res, path.join(PUBLIC_DIR, 'login.html'));
  if (url === '/api/login' && req.method === 'POST') return handleLogin(req, res, authConfig);

  if (url === '/api/logout') return handleLogout(req, res);

  requireAuth(req, res, authConfig, () => {

    if (url === '/api/uptime') {
      return send(res, 200, uptimeLog.getAllUptime());
    }

    if (url === '/api/sites')    return send(res, 200, sitesConfig);
    if (url === '/api/apps')     return send(res, 200, appsConfig);
    if (url === '/api/health')   return send(res, 200, { status: 'ok', uptime: process.uptime(), checked: Object.keys(healthData).length });
    if (url === '/api/status')   return send(res, 200, healthData);

    if (url === '/api/settings') {
      const safe = JSON.parse(JSON.stringify(settings));
      if (safe.auth) safe.auth = { enabled: safe.auth.enabled };
      return send(res, 200, safe);
    }

    if (url === '/' || url === '/index.html') return serveFile(res, path.join(PUBLIC_DIR, 'index.html'));

    if (url.startsWith('/api/sites/delete/') && req.method === 'DELETE') {
      const siteId = url.replace('/api/sites/delete/', '');
      let deleted = false;
      sitesConfig.platforms.forEach(p => {
        const idx = p.sites.findIndex(s => s.id === siteId);
        if (idx !== -1) { p.sites.splice(idx, 1); deleted = true; }
      });
      if (deleted) {
        fs.writeFileSync(path.join(CONFIG_DIR, 'sites.json'), JSON.stringify(sitesConfig, null, 2));
        delete healthData[siteId];
        return send(res, 200, { ok: true });
      }
      return send(res, 404, { error: 'Site not found' });
    }

    if (url.startsWith('/api/sites/edit/') && req.method === 'PUT') {
      const siteId = url.replace('/api/sites/edit/', '');
      let body = '';
      req.on('data', c => body += c);
      req.on('end', () => {
        try {
          const updates = JSON.parse(body);
          let found = false;
          sitesConfig.platforms.forEach(p => {
            const s = p.sites.find(s => s.id === siteId);
            if (s) { Object.assign(s, updates); found = true; }
          });
          if (found) {
            fs.writeFileSync(path.join(CONFIG_DIR, 'sites.json'), JSON.stringify(sitesConfig, null, 2));
            return send(res, 200, { ok: true });
          }
          send(res, 404, { error: 'Site not found' });
        } catch { send(res, 400, { error: 'Bad request' }); }
      });
      return;
    }

    const filePath = path.join(PUBLIC_DIR, url);
    if (fs.existsSync(filePath) && fs.statSync(filePath).isFile()) return serveFile(res, filePath);

    send(res, 404, { error: 'Not found' });
  });
});

server.listen(hub.port, () => {
  console.log(`\n  HumbleHUB running at http://localhost:${hub.port}`);
  console.log(`  Auth: ${authConfig.enabled ? 'ENABLED' : 'disabled'}`);
  console.log(`  Checking ${flatSites(sitesConfig).length} sites every ${hub.checkIntervalSeconds}s\n`);

});
